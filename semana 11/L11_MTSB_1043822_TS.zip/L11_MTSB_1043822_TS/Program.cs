﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_MTSB_1043822_TS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int largo = 0;
            int[] num;
            int suma8 = 0;
            int sumaimpares = 0;
            int sumapares = 0;


            Console.WriteLine("Ingrese la cantidad de numeros que deseea ingresar al vector");
            largo = int.Parse(Console.ReadLine());  

            num = new int[largo];

            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine("ingresar número");
                num[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Los números ingresados son: ");
            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine(num[i] + "");
                suma8 += num[i];
            }
            Console.WriteLine("La suma es: " + suma8);


            for (int i = 0; i < num.Length; i=i+2)
            {
                sumaimpares += num[i];
            }
            Console.WriteLine("La suma de los numeros impares es: " + sumaimpares);

            for (int i = 1; i < num.Length; i+=2)
            {
                sumapares += num[i];
            }
            
            Console.WriteLine("La suma de los numeros pares es: " + sumapares);
            Console.WriteLine("La longitud del arreglo es: " + largo);

            Console.ReadKey();
        }
        
    }
}
