﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L10_MTSB_1043822
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double catetoA = Convert.ToDouble(textBox1.Text);
            double anguloA = Convert.ToDouble(textBox2.Text);

            triangulorectangulo objTriangulo = new triangulorectangulo(catetoA, anguloA);

            double catetoB;
            double anguloB;
            double hipotenusa;
            double area;

            catetoB = objTriangulo.ObtenerCatetoB();
            anguloB = objTriangulo.ObtenerAnguloOpuestoB();
            hipotenusa = objTriangulo.ObtenerHipotenusa();
            area = objTriangulo.ObtenerArea();

            label2.Text = "El cateto A es: " + catetoA;
            label3.Text = "El cateto B es: " + catetoB;
            label4.Text = "El angulo OpuestoA es: " + anguloA;
            label5.Text = "El angulo OpuestoB es: " + anguloB;
            label6.Text = "La hipotenusa es: " + hipotenusa;
            label7.Text = "El area es: " + area ;
        }
    }
}
