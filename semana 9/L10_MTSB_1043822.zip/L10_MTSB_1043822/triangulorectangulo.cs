﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_MTSB_1043822
{
    internal class triangulorectangulo
    {
        double catetoA;
        double anguloA;
        double catetoB;
        double anguloB;
        double hipotenusa;
        double area;

        public triangulorectangulo(double cateA, double angA)
        {
            catetoA = cateA;
            anguloA = angA;
        }
        public double ObtenerCatetoA()
        {
            return catetoA;
        }
        public double ObtenerCatetoB()
        {
            catetoB = Math.Round(catetoA / Math.Tan(anguloA),3);
            return catetoB;
        }
        public double ObtenerHipotenusa()
        {
            hipotenusa = Math.Round(Math.Sqrt((catetoA * catetoA + catetoB * catetoB)),3);
            return hipotenusa;
        }
        public double ObtenerAnguloOpuestoA()
        {
            return anguloA;
        }
        public double ObtenerAnguloOpuestoB()
        {
            anguloB = (180 - anguloA - 90);
            return anguloB;
        }
        public double ObtenerArea()
        {
            area = Math.Round((catetoA * catetoB) /2, 3);
            
            return area;
        }
}
    }
