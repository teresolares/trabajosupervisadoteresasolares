﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace L3_MTSB_1043822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] menum1 = new int[5, 5];
            int[,] menum2 = new int[10, 10];
            string menu="";
            Random rand = new Random();
            int suma = 0;

            while (menu != "d")
            {

                Console.WriteLine(" ---------------------------------------------");
                Console.WriteLine("|   MENÚ                                     |");
                Console.WriteLine("|   a. Llenar matriz                         |");
                Console.WriteLine("|   b. Sumatoria                             |");
                Console.WriteLine("|   c. Tablas de multiplicar                 |");
                Console.WriteLine("|   d. Salir                                 |");
                Console.WriteLine(" ---------------------------------------------");
                Console.Write("Coloque su número de opción: ");

                menu = Console.ReadLine();


                switch (menu)
                {
                    case "a":

                        for (int i = 0; i < 5; i++)
                        {
                            for (int j = 0; j < 5; j++)
                            {
                                menum1[i, j] = rand.Next(150);
                                Console.Write(menum1[i, j] + "\t");
                            }
                            Console.WriteLine();
                        }

                        break;

                    case "b":

                        for (int i = 0; i < 5; i++)
                        {
                            for (int j = 0; j < 5; j++)
                            {

                                suma = suma + menum1[i, j];


                            }
                        }
                        Console.WriteLine("La suma de la matriz es : " + suma);
                        break;

                    case "c":

                        
                        for (int i = 0; i < 10; i++)
                        {
                            for(int j = 0; j < 10; j++)
                            {
                                menum2[i, j] = (i+1) * (j+1);
                                Console.Write(menum2[i,j] + "\t");
                            }
                            Console.WriteLine();
                        }
                        
                        break;
                }
            }
            Console.ReadKey();

        }
    }
}
